class Score(object):
	name = 'player'
	score = 0

	# initializes score and players name
	def __init__(self, name, score):
		raise ValueError ('todo')

	# returns the name associated with score
	def get_name(self):
		raise ValueError ('todo')

	# returns score of player
	def get_score(self):
		raise ValueError ('todo')