#!/bin/sh
# For Mac Users, to make the exe file ofr the game.
pyinstaller --onefile game.py --name mygame