# importing package to be able to run the tests
from nose.tools import *
# Here you should import all the modules/classes you want to test
from game.scores import Score
import game.game

# define a function like these for each class/module you test.
def test_scores():
	raise ValueError ('todo')

# etc...